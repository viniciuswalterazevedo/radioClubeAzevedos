function menuFunction(verificador){
    
    const menu = document.getElementById('menu')
    const nav = document.getElementById('nav')

    if (verificador == 1){

        menu.style.display = 'none'
        nav.style.display = 'block'

    }else if (verificador == 2){

        menu.style.display = 'block'
        nav.style.display = 'none'

    }
    
}